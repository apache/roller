/*
GNU Lesser General Public License

EkitApplet - Java Swing HTML Editor & Viewer Applet
Copyright (C) 2000-2002  Howard A Kistler

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package com.hexidec.ekit;

import java.awt.BorderLayout;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Vector;
import javax.swing.JApplet;
import javax.swing.JLabel;

/** EkitApplet
  * Applet for editing and saving HTML in a Java browser component
  *
  * @author Howard Kistler
  * @version 0.9e
  *
  * REQUIREMENTS
  * Java 2 (JDK 1.3 or 1.4)
  * Swing Library
  */

public class EkitApplet extends JApplet
{
	/* Components */
	EkitCore ekitCore;

	private JLabel jlblStatus;

	/* Constants */
	private final int CLIPBOARD_CUT   = 1;
	private final int CLIPBOARD_COPY  = 2;
	private final int CLIPBOARD_PASTE = 3;
	// System Clipboard handle (disabled for now)
//	private java.awt.datatransfer.Clipboard sysClipboard = Toolkit.getDefaultToolkit().getSystemClipboard();

	/** Constructor
	  */
	public EkitApplet()
	{
		getRootPane().putClientProperty("defeatSystemEventQueueCheck", Boolean.TRUE);
	}

	/** Applet Init
	  */
	public void init()
	{
		String sRawDocument = this.getParameter("DOCUMENT");
		String sStyleSheetRef = this.getParameter("STYLESHEET");
		URL urlCSS = (URL)null;
		try
		{
			if(sStyleSheetRef != null && sStyleSheetRef.length() > 0)
			{
				urlCSS = new URL(this.getCodeBase(), sStyleSheetRef);
			}
		}
		catch(MalformedURLException murle)
		{
			murle.printStackTrace(System.err);
		}
		boolean showToolBar = true;
		if(this.getParameter("TOOLBAR") != null) { showToolBar = this.getParameter("TOOLBAR").toLowerCase().equals("true"); }
		boolean showViewSource = ((this.getParameter("SOURCEVIEW") != null && this.getParameter("SOURCEVIEW").toLowerCase().equals("true")));
		String sLanguage = this.getParameter("LANGCODE");
		String sCountry = this.getParameter("LANGCOUNTRY");
		boolean editModeExclusive = true;
		if(this.getParameter("EXCLUSIVE") != null) { editModeExclusive = this.getParameter("EXCLUSIVE").toLowerCase().equals("true"); }
		boolean showMenuIcons = true;
		if(this.getParameter("MENUICONS") != null) { showMenuIcons = this.getParameter("MENUICONS").toLowerCase().equals("true"); }

/* System Clipboard versions of menu commands
		JMenuItem jmiCut     = new JMenuItem(Translatrix.getTranslationString("Cut"));   jmiCut.setActionCommand("textcut");     jmiCut.addActionListener(this);   jmiCut.setAccelerator(KeyStroke.getKeyStroke('X', java.awt.Event.CTRL_MASK, false));   if(showMenuIcons) { jmiCut.setIcon(getEkitIcon("Cut")); }     jMenuEdit.add(jmiCut);
		JMenuItem jmiCopy    = new JMenuItem(Translatrix.getTranslationString("Copy"));  jmiCopy.setActionCommand("textcopy");   jmiCopy.addActionListener(this);  jmiCopy.setAccelerator(KeyStroke.getKeyStroke('C', java.awt.Event.CTRL_MASK, false));  if(showMenuIcons) { jmiCopy.setIcon(getEkitIcon("Copy")); }   jMenuEdit.add(jmiCopy);
		JMenuItem jmiPaste   = new JMenuItem(Translatrix.getTranslationString("Paste")); jmiPaste.setActionCommand("textpaste"); jmiPaste.addActionListener(this); jmiPaste.setAccelerator(KeyStroke.getKeyStroke('V', java.awt.Event.CTRL_MASK, false)); if(showMenuIcons) { jmiPaste.setIcon(getEkitIcon("Paste")); } jMenuEdit.add(jmiPaste);
*/

		ekitCore = new EkitCore(sRawDocument, urlCSS, showViewSource, showMenuIcons, editModeExclusive, sLanguage, sCountry);

		Vector vcMenus = new Vector();
		vcMenus.add("edit");
		vcMenus.add("view");
		vcMenus.add("font");
		vcMenus.add("format");
		vcMenus.add("insert");
		vcMenus.add("forms");
		vcMenus.add("search");
		vcMenus.add("help");
		this.setJMenuBar(ekitCore.getCustomMenuBar(vcMenus));

		jlblStatus = new JLabel();
		
		/* Add the components to the app */
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(ekitCore, BorderLayout.CENTER);
		this.getContentPane().add(jlblStatus, BorderLayout.SOUTH);
		if(showToolBar)
		{
			Vector vcTools = new Vector();
			vcTools.add("edit");
			vcTools.add("format");
			vcTools.add("insert");
			vcTools.add("source");
			vcTools.add("styles");
			this.getContentPane().add(ekitCore.getCustomToolBar(vcTools), BorderLayout.NORTH);
		}
	}

	/* Applet methods */
	public void start()   { ; }
	public void stop()    { ; }
	public void destroy() { ; }

/** Cut/Copy/Paste that uses the System Clipboard
  */
/* System Clipboard Action operations
			else if(command.equals("textcut"))
			{
				clipboardOp(CLIPBOARD_CUT);
			}
			else if(command.equals("textcopy"))
			{
				clipboardOp(CLIPBOARD_COPY);
			}
			else if(command.equals("textpaste"))
			{
				clipboardOp(CLIPBOARD_PASTE);
			}
*/
/* Cannot be enabled without security overrides in place (such as a valid security certificate)
	public void clipboardOp(int mode)
	{
		if(mode == CLIPBOARD_CUT || mode == CLIPBOARD_COPY)
		{
			String selText = jtpMain.getSelectedText();
			java.awt.datatransfer.StringSelection selTextString = new java.awt.datatransfer.StringSelection(selText);
			java.awt.datatransfer.ClipboardOwner nullCallback = null;
			sysClipboard.setContents(selTextString, nullCallback);
			if(mode == CLIPBOARD_CUT)
			{
				jtpMain.replaceSelection((String)null);
			}
		}
		else if(mode == CLIPBOARD_PASTE)
		{
			java.awt.datatransfer.Transferable transText = sysClipboard.getContents(this);
			if(transText.isDataFlavorSupported(java.awt.datatransfer.DataFlavor.stringFlavor))
			{
				String selText = (String)null;
				try
				{
					selText = (String)(transText.getTransferData(java.awt.datatransfer.DataFlavor.stringFlavor));
				}
				catch(java.awt.datatransfer.UnsupportedFlavorException ufe)
				{
					// Clipboard does not support Strings - shouldn't happen ever
					return;
				}
				catch(IOException ioe)
				{
					// Error reading clipboard
					return;
				}
				if(selText != null)
				{
					jtpMain.replaceSelection(selText);
				}
			}
		}
	}
*/

	/** Method for passing back the document text to the applet's container.
	  * This is the entire document, including the top-level HTML tags.
	  */
	public String getDocumentText()
	{
		return ekitCore.getDocumentText();
	}

	/** Method for passing back the document body to the applet's container.
	  * This is only the text contained within the BODY tags.
	  */
	public String getDocumentBody()
	{
		return ekitCore.getDocumentSubText("body");
	}

}
