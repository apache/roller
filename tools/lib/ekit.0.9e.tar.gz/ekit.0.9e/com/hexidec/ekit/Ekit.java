/*
GNU Lesser General Public License

Ekit - Java Swing HTML Editor & Viewer
Copyright (C) 2000-2002  Howard A Kistler

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package com.hexidec.ekit;

import java.awt.BorderLayout;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.io.FileWriter;
import javax.swing.JFrame;

/** Ekit
  * App for editing and saving HTML in a Java text component
  *
  * @author Howard Kistler
  * @version 0.9e
  *
  * REQUIREMENTS
  * Java 2 (JDK 1.3 or 1.4)
  * Swing Library
  */

public class Ekit extends JFrame implements WindowListener
{
	private EkitCore ekitCore;

	private File currentFile = (File)null;

	/** Master Constructor
	  * @param sDocument         [String]  A text or HTML document to load in the editor upon startup.
	  * @param sStyleSheet       [String]  A CSS stylesheet to load in the editor upon startup.
	  * @param sRawDocument      [String]  A document encoded as a String to load in the editor upon startup.
	  * @param urlStyleSheet     [URL]     A URL reference to the CSS style sheet.
	  * @param showToolBar       [boolean] Specifies whether the app should include the toolbar.
	  * @param showViewSource    [boolean] Specifies whether or not to show the View Source window on startup.
	  * @param showMenuIcons     [boolean] Specifies whether or not to show icon pictures in menus.
	  * @param editModeExclusive [boolean] Specifies whether or not to use exclusive edit mode (recommended on).
	  * @param sLanguage         [String]  The language portion of the Internationalization Locale to run Ekit in.
	  * @param sCountry          [String]  The country portion of the Internationalization Locale to run Ekit in.
	  * @param debugMode         [boolean] Specifies whether to show the Debug menu or not.
	  */
	public Ekit(String sDocument, String sStyleSheet, String sRawDocument, URL urlStyleSheet, boolean showToolBar, boolean showViewSource, boolean showMenuIcons, boolean editModeExclusive, String sLanguage, String sCountry, boolean debugMode)
	{
		ekitCore = new EkitCore(sDocument, sStyleSheet, sRawDocument, urlStyleSheet, showViewSource, showMenuIcons, editModeExclusive, sLanguage, sCountry, debugMode);

		ekitCore.setFrame(this);

		/* Add the components to the app */
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(ekitCore, BorderLayout.CENTER);
		if(showToolBar)
		{
			this.getContentPane().add(ekitCore.getToolBar(), BorderLayout.NORTH);
		}

		this.setJMenuBar(ekitCore.getMenuBar());

		this.addWindowListener(this);

		this.updateTitle();
		this.pack();
		this.show();
	}

	public Ekit()
	{
		this(null, null, null, null, true, false, true, true, null, null, false);
	}

	/* WindowListener methods */
	public void windowClosing(WindowEvent we)
	{
		this.dispose();
		System.exit(0);
	}
	public void windowOpened(WindowEvent we)      { ; }
	public void windowClosed(WindowEvent we)      { ; }
	public void windowActivated(WindowEvent we)   { ; }
	public void windowDeactivated(WindowEvent we) { ; }
	public void windowIconified(WindowEvent we)   { ; }
	public void windowDeiconified(WindowEvent we) { ; }

	/** Convenience method for updating the application title bar
	  */
	private void updateTitle()
	{
		this.setTitle(ekitCore.getAppName() + (currentFile == null ? "" : " - " + currentFile.getName()));
	}

	/** Main method
	  */
	public static void main(String[] args)
	{
		if(args.length > 0)
		{
			String sDocument = null;
			String sStyleSheet = null;
			String sRawDocument = null;
			URL    urlStyleSheet = null;
			boolean includeToolBar = true;
			boolean includeViewSource = false;
			boolean includeMenuIcons = true;
			boolean modeExclusive = true;
			String sLang = null;
			String sCtry = null;
			boolean debugOn = false;
			for(int i = 0; i < args.length; i++)
			{
				if     (args[i].equals("-t"))     { includeToolBar = true; }
				else if(args[i].equals("-T"))     { includeToolBar = false; }
				else if(args[i].equals("-s"))     { includeViewSource = true; }
				else if(args[i].equals("-S"))     { includeViewSource = false; }
				else if(args[i].equals("-m"))     { includeMenuIcons = true; }
				else if(args[i].equals("-M"))     { includeMenuIcons = false; }
				else if(args[i].equals("-x"))     { modeExclusive = true; }
				else if(args[i].equals("-X"))     { modeExclusive = false; }
				else if(args[i].startsWith("-f")) { sDocument = args[i].substring(2, args[i].length()); }
				else if(args[i].startsWith("-c")) { sStyleSheet = args[i].substring(2, args[i].length()); }
				else if(args[i].startsWith("-r")) { sRawDocument = args[i].substring(2, args[i].length()); }
				else if(args[i].startsWith("-u"))
				{
					try
					{
						urlStyleSheet = new URL(args[i].substring(2, args[i].length()));
					}
					catch(MalformedURLException murle)
					{
						murle.printStackTrace(System.err);
					}
				}
				else if(args[i].startsWith("-l"))
				{
					if(args[i].indexOf('_') > -1)
					{
						sLang = args[i].substring(2, args[i].indexOf('_'));
						sCtry = args[i].substring(args[i].indexOf('_') + 1, args[i].length());
					}
				}
				else if(args[i].equals("-d"))     { debugOn = true; }
				else if(args[i].equals("-D"))     { debugOn = false; }
			}
			Ekit ekit = new Ekit(sDocument, sStyleSheet, sRawDocument, urlStyleSheet, includeToolBar, includeViewSource, includeMenuIcons, modeExclusive, sLang, sCtry, debugOn);
		}
		else
		{
			Ekit ekit = new Ekit();
		}
	}

}