<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!-- Document Author - Thomas Gauweiler (gauweiler@fzi.de) -->
<HTML>
<HEAD>
<TITLE>Ekit Applet Output</TITLE>
</HEAD>
<BODY BGCOLOR="#FFFFFF">
<?php
 echo ("$EkitH");
// phpinfo();
?>
</BODY>
</HTML>